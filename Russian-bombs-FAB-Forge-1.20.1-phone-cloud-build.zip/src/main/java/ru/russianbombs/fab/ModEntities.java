package ru.russianbombs.fab;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RussianBombsFab.MODID);

    public static final RegistryObject<EntityType<FabBombEntity>> FAB_BOMB =
            ENTITY_TYPES.register("fab_bomb", () -> EntityType.Builder
                    .<FabBombEntity>of(FabBombEntity::new, MobCategory.MISC)
                    .sized(0.45F, 0.45F)
                    .clientTrackingRange(8)
                    .updateInterval(10)
                    .build("fab_bomb"));
}
